<div class="ads">
    <div class="ads-margin">
        <?php if ($enable_ads): ?>
            <div class="ads-title">
                Advertisement
            </div>
        <?php endif; ?>
        <div class="ads" style="width: 250px; height:250px;">
            <?php if ($enable_ads) include 'ads/250x250.php'; ?>
        </div>
    </div>
</div>

