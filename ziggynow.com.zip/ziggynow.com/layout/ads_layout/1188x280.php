<div class="ads">
    <div class="ads-margin">
        <?php if ($enable_ads): ?>
            <div class="ads-title">
                Advertisement
            </div>
        <?php endif; ?>
        <div  style="width: 1188px; height:280px;">
            <?php if ($enable_ads) include 'ads/1188x280.php'; ?>
        </div>
    </div>
</div>