<div class="ads">
    <div class="ads-margin">
        <?php if ($enable_ads): ?>
            <div class="ads-title">
                Advertisement
            </div>
        <?php endif; ?>
        <div class="ads" style="width: 336px; height:280px;">
            <?php if ($enable_ads) include 'ads/336x280.php'; ?>
        </div>
    </div>
</div>
