<header class="page-header">
    <div class="container">
        <div class="row">
            <div class="wrap-page-header">
                <h1 class="text-1"><?php echo $title; ?></h1>
                <p class="text-2"><?php echo $excerpt; ?></p>
            </div>
        </div>
    </div>
</header>